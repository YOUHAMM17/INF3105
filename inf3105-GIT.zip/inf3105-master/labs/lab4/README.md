# Lab 4 : Classes génériques Pile et File

[Rappels, trace tâche 2 et solution tâche 4.](http://ericbeaudry.ca/INF3105/lab4/lab4+.pdf)
