# Arbre rouge-noir - Insertion

Insérer 2, 1, 4, 5, 9, 3, 6, 7 dans un arbre rouge-noir.

## Insérer 2 - Cas 1
<img src="inserer2.png">

## Insérer 1 - Cas 2
<img src="inserer1.png">

## Insérer 4 - Cas 2
<img src="inserer4.png">

## Insérer 5 - Cas 3 + Cas 2
<img src="inserer5.png">

## Insérer 9 - Cas 4.2
<img src="inserer9.png">

## Insérer 3 - Cas 3 + Cas 2
<img src="inserer3.png">

## Insérer 6 - Cas 2
<img src="inserer6.png">

## Insérer 7 - Cas 4.1 + Cas 4.2
<img src="inserer7.png">
