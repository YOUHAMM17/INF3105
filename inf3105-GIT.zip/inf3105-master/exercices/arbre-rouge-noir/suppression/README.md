# Arbre rouge-noir - Suppression

## Cas 4
Supprimer 20 de l'arbre rouge-noir suivant.

**Avant**
<img src="cas4a.png">

**Après**
<img src="cas4b.png">

## Cas 6
Supprimer -10 de l'arbre rouge-noir suivant.

**Avant**
<img src="cas6a.png">

**Après**
<img src="cas6b.png">

## Cas 3 + Cas 1
Supprimer -10 de l'arbre rouge-noir suivant.

**Avant**

<img src="cas3a.png">

**Après**

<img src="cas3b.png">

## Cas 3 + Cas 5 + Cas 6
Supprimer -40 de l'arbre rouge-noir suivant.

**Avant**

<img src="cas3c.png">

**Après**

<img src="cas3d.png">

## Cas 2 + Cas 4
Supprimer 10 de l'arbre rouge-noir suivant en utilisant le sucesseur comme remplaçant.

**Avant**

<img src="cas2a.png">

**Après**

<img src="cas2b.png">
