# Quiz 1 Été 2015

## Question 1
* Aucune de ces réponses n'est correcte.

## Question 2
* O(5n - 7) = O(n)
* O(0.1n² + 8n - 21) = O(n²)
* O(n²) < O(n³)

## Question 3
Affiche F3 lorsque 2 éléments distincts multipliés ensemble donnent un troisième élément distinct.

## Question 4
* O(n³)

## Question 5
* c
* p
* i
* d

## Question 6
* tab est un pointeur
* tab est un tableau
* le tableau est alloué sur le tas (heap)

## Question 7
* requiert un jeu de tests
* est sensible à la qualité de l'implémentation

## Question 8
* i = 1, a = 0, b = [2, 4] => 3 fois
* i = 2, a = [0, 1], b = [3, 4] => 4 fois
* i = 3, a = [0, 2], b = 4 => 3 fois
* compte = 10

## Question 9
O(n²)

## Question 10
* Un ensemble de fonctions dont la croissance est similaire

## Question 11
O(n³) + O(n²) + O(n³) = O(n³)

## Question 12
* compte = 2

## Question 13
* O(n log n)

## Question 14
Affiche F2 lorsque le tableau contient 2 éléments pairs distincts égaux.

## Question 15
Affiche F1 lorsque la somme de deux cases est égale à une case au milieu des deux.

exemples:
* 5 1 4 2 4 1
* 3 1 2 1
* 3 1 3 2
