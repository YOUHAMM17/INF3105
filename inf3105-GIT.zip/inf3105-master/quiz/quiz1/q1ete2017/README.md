## Référence
* [Counting sort](https://en.wikipedia.org/wiki/Counting_sort)
