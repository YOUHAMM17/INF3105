# 3.2 Partie B

Il n'est pas nécessaire de modifier le programme car l'arbre AVL maintient l'ordre des données.

# Partie C - Complexité temporelle

* estimeTemperature() : O(log n)
* calculeMoyenne() : O(n)
