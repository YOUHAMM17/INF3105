# 1.1 C++

Le programme affiche la ligne suivante :
1 3 5 7 5 ? ? ? : 16

Les points d'interrogation représente des valeurs imprévisibles car elles n'ont pas été initialisées.

