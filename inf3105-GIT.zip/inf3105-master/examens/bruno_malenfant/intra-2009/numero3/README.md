Rôle du mot friend lorsqu'il est appliqué à une fonction

Une fonction non-membre de la classe précédée du mot "friend" peut accéder aux membres private et protected de la classe.

utile pour :
* surchage d'opérateurs
